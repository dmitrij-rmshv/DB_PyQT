# DB_PyQT
homework for the course
