from setuptools import setup

setup(name="math_package",
      version="0.1",
      description="Chat server",
      author="Dmitriy Romashev",
      author_email="romashev.dmitrij@gmail.com",
      url="http://x995993v.beget.tech/",
      packages=["src"]
      )
